---
name: witfoo-board-briefing
description: Use when someone asks for a board, executive or leadership briefing, slide deck or security update built from their WitFoo appliance. Builds an eight-slide deck in the bundled board template from WitFoo's latest executive figures, cost and savings, compliance standing and significant work units, with the source of every number in the speaker notes.
---

# WitFoo board briefing

You are preparing a board briefing for the signed-in user (usually the CISO) from their own WitFoo appliance, through the WitFoo connector. You see only what their role allows.

## What to fetch

Ask the appliance for figures WitFoo has already worked out. Do not wade through raw logs to recompute them.

1. WitFoo's latest executive figures, with the report date WitFoo gives. WitFoo reports its latest figures, not a period you choose.
2. Cost and savings: total savings, ROI, prevented revenue loss, prevented brand damage, prevented legal costs, IT labour savings, false-positive cost, staff needed and budgeted, and the complex and routine work-unit counts, in the report's currency and with its date. Per-tool savings may come from the tool-effectiveness report.
3. Compliance standing: each framework's compliance percentage and how many required controls are met, as of the report date. WitFoo does not give earlier figures.
4. The most severe work units created since a date the user names. If they name none, ask once, or use the last 90 days and say so. Say in the notes on slide 3 which dates the units come from. What happened, from their details. For how each was handled: its notes, assignments, response tasks and activity log (which records status changes and notes, with who made them, and keeps 90 days).

Do not regenerate WitFoo's reports. That is a change.

## The deck

Use `assets/WitFoo_Board_Briefing_Template.pptx`. Keep its layouts, fonts and colors. Eight slides, in this order:

1. Title: the organization's security program, the date the figures are as of, "Draft for the CISO's review". If the user asked for a period, say in the notes that the figures are as of that date.
2. Posture at a glance: three to five headline figures from the executive figures.
3. Significant incidents: up to three work units, one line each, in plain English.
4. How we responded: what was done about each, and by whom, as WitFoo records it.
5. Compliance standing: each framework's percentage and controls met, as of the report date.
6. What the program saves: the savings and where they come from, as WitFoo's report shows them.
7. Risks and asks: what the board should know or decide. Only what the evidence supports.
8. Evidence: where every figure in the deck came from.

## Rules

- Plain English. No jargon a board member would need explained.
- Every number comes from the appliance. Put the source of each number and its report date in that slide's speaker notes.
- Where WitFoo marks a report as low confidence, say in the notes that its figures may be understated.
- Invent no figure, trend or comparison. State no movement in compliance or any other figure unless the user gives you the earlier figures; otherwise write "movement not available" in the notes. If a figure is missing, leave it out and say so in the notes.
- Name people as WitFoo names them. If a task shows only a user ID, say "assigned" without a name. Notes, assignments and tasks are read through tools that WitFoo marks as able to make changes; if a connection approved for reading only is refused them, say so in the notes.
- Keep the footer "Draft for the CISO's review" on every slide.
- Change nothing on the appliance.
