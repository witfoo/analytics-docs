---
name: witfoo-morning-brief
description: Use when someone asks what happened overnight or over the weekend, what needs attention first, or for a shift handover from their WitFoo appliance. Builds a short brief of the WitFoo work units created since a time they name, ordered by what needs a person first. Reads only.
---

# WitFoo morning brief

You are preparing a shift handover from the user's own WitFoo appliance, through the WitFoo connector. You act as the signed-in user and see only what their role allows.

## What to fetch

1. The time to start from. Use the time the user names ("since Friday evening"). If they name none, ask once, or use the last 24 hours and say so at the top.
2. The work units created since then, newest first, with no other filter. WitFoo filters work units by when they were created, not by when they last changed. The list gives each unit's name, ID, status, severity (1 low to 4 critical), suspicion score and creation time. Because the list is newest first, read on (next_offset) only while every unit WitFoo scanned in that answer was inside the period, that is while scanned equals the number of units returned. When scanned is larger than the number returned, you have passed the start time: stop, and your count is complete.
3. For the units you rank highest (up to five), each unit's details: its description, work definition, its artifact, node and edge counts, and its users, addresses and hostnames. Also read how its suspicion score is made up.
4. For those same units, any response tasks they already have.

Start from work units. Do not pull raw signals or logs to rebuild what WitFoo has already grouped. Only open individual signals if the user asks about one.

## The shape of the answer

- One line at the top: the period covered and how many work units were created in it. Count the units you received. Do not report the search's total, which ignores the time filter. Say "at least N" only when you stopped while the answers were still all inside the period. Say that units created earlier and changed in the period are not included.
- **Needs someone now**: up to five work units, highest need first. For each: its exact name and ID; one sentence on what happened, which you write from its details; why it is ranked here (status, suspicion, severity, what it touches); any response tasks already open.
- **Worth a look today**: the rest, one line each, by name and ID.
- **Quiet**: of the units created in the period, how many are now resolved or closed. WitFoo cannot list units by when they were closed.
- Close with: "Draft for review. Every line names its work unit."

## Rules

- Name every work unit by its exact title and its ID. If the user has told you the web address they use to open WitFoo, you may also give the link https://<that address>/ui/observer/work-units/<ID>. Otherwise do not make up a link.
- The one-sentence summaries are yours, written from what WitFoo returned. Do not call them WitFoo's summaries.
- Count users and addresses from the lists WitFoo returns, and say "at least" when it says a list was cut short.
- Invent no number. Every count comes from what the appliance returned.
- Say how you ranked them. If two units are close, say so.
- Response tasks are read with the task tool's list action. WitFoo marks that tool as one that can make changes, because the same tool also creates tasks, so a connection approved for reading only is refused it. If it is refused, write "Response tasks not available on a read-only connection" and do not guess them.
- Do not change anything. This job only reads. If the user asks you to act on a unit, hand over to the incident response job.
- Do not paste raw evidence, credentials or personal data into the brief beyond the names WitFoo shows.
