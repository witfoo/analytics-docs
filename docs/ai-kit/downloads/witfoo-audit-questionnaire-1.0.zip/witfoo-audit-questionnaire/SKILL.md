---
name: witfoo-audit-questionnaire
description: Use when someone attaches or pastes a security, audit, vendor-risk or compliance questionnaire and asks for it to be answered from their WitFoo compliance figures. Answers each question with the framework and WitFoo's figure for it, states failed checks plainly, and adds WitFoo's remediation where WitFoo gives one.
---

# WitFoo audit questionnaire

You are filling in a security questionnaire from the organization's own WitFoo compliance figures, through the WitFoo connector, as the signed-in user.

## What to fetch

1. The questionnaire the user attached or pasted. Keep its questions and their order exactly.
2. WitFoo's compliance figures: for each framework it tracks, the compliance percentage and how many of its required controls are met, with the report date and any low-confidence mark. These figures name frameworks, not individual controls.
3. Where the organization uses WitFoo's cloud-configuration audit: the audit findings and check results that bear on a question (pass, fail, error or not applicable), and the remediation WitFoo gives for a failed check. An audit compliance of 0% with nothing evaluated means nothing was evaluated, not that everything failed.
4. Supporting figures only where a question asks for them (for example, coverage or counts), from WitFoo's reports.

## The shape of the answer

Return the questionnaire with these columns filled for every question:

| Column | What goes in it |
|---|---|
| Answer | A direct answer in one to three sentences |
| Framework and standing | The framework, and WitFoo's figure for it: the compliance percentage and how many required controls are met, as of the report date. Where a cloud-configuration check answers the question, that check's ID and its result in WitFoo's words (pass, fail, error, not applicable) |
| Evidence | The WitFoo report and its date, or the audit check ID and finding ID, named so a reviewer can find it. Say when WitFoo marked a report as low confidence |
| Remediation | Only where a WitFoo cloud-configuration check maps to the question and failed: that check's remediation, in WitFoo's words. Otherwise "No WitFoo remediation for this item" |

If the user gave a file, return the same file type with the columns filled. Otherwise return a table.

## Rules

- Use only the standings WitFoo reported. Do not write "Met", "Partially met", "Not evidenced" or any other label WitFoo did not give.
- Where a check failed, say "Fail" plainly. Where a framework's figure is low, give the figure plainly. An honest answer to an auditor is worth more than a confident one.
- Claim no control identifier, certification or attestation that the appliance did not report. WitFoo's compliance figures name frameworks, not controls.
- If WitFoo holds nothing that answers a question, say "Not answered from WitFoo; needs a person" and move on.
- Invent no number.
- Change nothing on the appliance.
- Put "Draft for review. A person reads every answer before it is sent." at the top.
